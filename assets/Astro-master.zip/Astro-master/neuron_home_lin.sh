# Path to NEURON installation folder in Linux style

export NEURON_HOME_LIN="/C/nrn"