These files can be added to the cataloge of Astro after deleting 
cadifus.mod file

Uses electroneutral, exponentially decaying IP3 source 
to emulate effect of activating bradykinin receptors on IP3.
Equivalent to approach used by Fink et al. 2000 
to represent bradykinin action.