#!sh

# The next paths must be adjusted before the first launch
NRNDIR="/C/Programs/nrn"
HPCDIR="/D/Work/UCL Phase 14/nano/clusterCaSim/hpc"