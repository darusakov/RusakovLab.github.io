function UpdateView()

    % The main controls
    UpdateViewControls();
    
    % Slider and gray strips
    AdjustSliderAndStrips(false);
    
end