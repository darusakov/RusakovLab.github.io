function AddPaths()
%% Add paths of all the m-files to the Matlab search path

    addpath('Core');
    addpath(genpath('GUI'));
    
end