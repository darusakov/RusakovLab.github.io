# ARACHNE. Full version.  

This version of  ARACHNE can be installed on any a computers claster and a host computer.

For the initial installation of ARACHNE to a cluster  a professional effort will be required. (see details in the Manual)

The "Full-version" contains two directories "host" and "worker"  for installation ARACHNE for any cluster operating under Linux/Windows and any host computer operating under Windows and with preinstalled MatLab. 

