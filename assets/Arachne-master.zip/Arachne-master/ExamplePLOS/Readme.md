# Input parameters

This directory contains 5 files with the input parameters for Arachne.

Each file corresponds to the plot for the manuscript submitted to Plos Comp Biol.

The initial distribution of active e-cells was set along diagonal from left-top to right-down.

### If you are using the demo version of Arachne, you do not create a network of more than 1000 neurons.
Do not use file PLOS_Basic large network.mat with 14000 neurons with Demo version!

