#include "AllModCurrents.h"



template
class AllModCurrents_e<float>;

template
class AllModCurrents_e<double>;

template
class AllModCurrents_i<float>;

template
class AllModCurrents_i<double>;
